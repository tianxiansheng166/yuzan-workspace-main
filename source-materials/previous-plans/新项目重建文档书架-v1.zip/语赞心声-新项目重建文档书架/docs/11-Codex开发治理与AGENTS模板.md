# 11 Codex 开发治理与 AGENTS 模板

## 一、AI 的角色

Codex 可以加速阅读、实现、测试和文档，但不能替代产品负责人、教研专家、安全负责人和真实用户验收。每个任务必须有范围、输入、完成标准和禁止事项。

## 二、任务拆分规则

一个 Codex 任务最多包含一个可独立验收的纵向切片，例如：

- “教师创建任务并发布到一个班级”
- “学生离线完成客观题并同步”
- “教研人员审核并发布课程版本”

禁止任务：

- “把全项目做成熟”
- “全面升级 UI”
- “加上所有 AI 功能”
- “直接重构全部后端”

## 三、每次任务模板

```text
目标：
用户场景：
允许修改的模块：
禁止修改的模块：
现有契约/ADR：
数据和权限边界：
异常与降级：
测试要求：
浏览器/接口验收步骤：
完成定义：
输出变更摘要和剩余风险。
```

## 四、建议 AGENTS.md

```markdown
# Project Rules

## Product
- The first release serves the curriculum-to-assignment-to-feedback loop.
- Do not add community, volunteer matching, payment, or knowledge graph features without an approved ADR.
- Never present mock data as live production data.

## Architecture
- Keep a modular monolith until an ADR approves a service split.
- Controllers do not access the ORM directly.
- Domain rules do not depend on HTTP, UI, or third-party SDKs.
- All API changes update OpenAPI contracts and tests.
- All tenant data access must include organization scope.

## Legacy
- The old project is read-only reference material.
- Do not copy site-polish.js, yx-design-upgrade.css, JSON persistence, or demo microservices.
- Legacy content must pass validation and review before import.

## Security
- No fallback production secrets.
- Never log passwords, tokens, raw personal data, or full student audio.
- Every write endpoint checks identity, role, organization, and resource ownership.
- Private files must not be exposed through public static directories.

## Offline
- Offline writes use globally unique operation IDs and an outbox.
- Sync endpoints are idempotent.
- Conflict behavior must be documented and tested.

## AI and Speech
- Store model and prompt versions for every generated result.
- AI output is reviewable and has a deterministic fallback.
- ASR similarity must not be labeled pronunciation scoring.
- Do not claim accuracy without an approved test set and report.

## Quality
- Run lint, typecheck, unit, integration, and relevant E2E tests.
- Add tests for permissions, failure states, offline states, and retries.
- Inspect the rendered UI at desktop and mobile widths.
- Include migration and rollback notes for schema changes.
```

## 五、AI 代码审查清单

- 是否引入了新业务范围？
- 是否绕过模块边界？
- 是否出现前端假数据兜底？
- 是否把权限判断只放在前端？
- 是否对 AI/文件/同步失败有回退？
- 是否补了测试、日志和迁移？
- 是否造成卡片套卡片或全局 CSS 覆盖？
- 是否能说明这次改动解决哪个真实用户任务？
