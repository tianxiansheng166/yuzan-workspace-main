# Project Rules

## Product
- The first release serves the curriculum-to-assignment-to-feedback loop.
- Do not add community, volunteer matching, payment, or knowledge graph features without an approved ADR.
- Never present mock data as live production data.

## Architecture
- Keep a modular monolith until an ADR approves a service split.
- Controllers do not access the ORM directly.
- Domain rules do not depend on HTTP, UI, or third-party SDKs.
- All API changes update OpenAPI contracts and tests.
- All tenant data access must include organization scope.

## Legacy
- The old project is read-only reference material.
- Do not copy site-polish.js, yx-design-upgrade.css, JSON persistence, or demo microservices.
- Legacy content must pass validation and review before import.

## Security
- No fallback production secrets.
- Never log passwords, tokens, raw personal data, or full student audio.
- Every write endpoint checks identity, role, organization, and resource ownership.
- Private files must not be exposed through public static directories.

## Offline
- Offline writes use globally unique operation IDs and an outbox.
- Sync endpoints are idempotent.
- Conflict behavior must be documented and tested.

## AI and Speech
- Store model and prompt versions for every generated result.
- AI output is reviewable and has a deterministic fallback.
- ASR similarity must not be labeled pronunciation scoring.
- Do not claim accuracy without an approved test set and report.

## Quality
- Run lint, typecheck, unit, integration, and relevant E2E tests.
- Add tests for permissions, failure states, offline states, and retries.
- Inspect the rendered UI at desktop and mobile widths.
- Include migration and rollback notes for schema changes.